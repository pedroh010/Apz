// ============================================================================
// systems/antigolpe.js
// Bloqueador de chave Pix antes da criação da sala
// ============================================================================

import { CONFIG } from "../utils/constants.js";

/**
 * Ativa o sistema anti-golpe em uma thread.
 * - Apaga qualquer chave Pix enviada por jogadores
 * - Não afeta o mediador da fila
 * - Desativa automaticamente quando a thread é renomeada para "pagar-..."
 */
export function ativarAntiGolpe(thread, mediadorId) {
  console.log(`[AntiGolpe] Ativado na thread ${thread.name}`);

  const collector = thread.createMessageCollector({
    time: 0,
    filter: m => !m.author.bot
  });

  collector.on("collect", async msg => {
    // Se thread já foi renomeada para "pagar-...", desativa
    if (thread.name.startsWith("pagar-")) {
      console.log("[AntiGolpe] Thread renomeada, bloqueio desativado");
      collector.stop("thread_renomeada");
      return;
    }

    // Ignorar mensagens do mediador
    if (msg.author.id === mediadorId) return;

    // Verificar se mensagem contém chave Pix
    if (CONFIG.REGEX.PIX.test(msg.content.trim())) {
      try {
        await msg.delete();
        console.log(`[AntiGolpe] Chave Pix bloqueada de ${msg.author.tag}`);
      } catch (err) {
        console.error("[AntiGolpe] Erro ao deletar chave Pix:", err.message);
      }
    }
  });

  collector.on("end", (collected, reason) => {
    console.log(`[AntiGolpe] Bloqueio encerrado: ${reason}`);
  });
}