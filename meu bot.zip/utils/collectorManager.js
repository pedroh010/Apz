// ============================================================================
// utils/collectorManager.js
// Sistema de persistência de botões após reiniciar bot
// ============================================================================

import fs from "fs";
import { ActionRowBuilder, ButtonBuilder, ButtonStyle } from "discord.js";

const COLLECTORS_FILE = "active_collectors.json";

// ============================================================================
// SALVAR E CARREGAR COLLECTORS
// ============================================================================

function saveCollector(data) {
  try {
    let collectors = [];
    
    if (fs.existsSync(COLLECTORS_FILE)) {
      collectors = JSON.parse(fs.readFileSync(COLLECTORS_FILE, "utf8"));
    }

    collectors.push({
      ...data,
      timestamp: Date.now()
    });

    fs.writeFileSync(COLLECTORS_FILE, JSON.stringify(collectors, null, 2));
    console.log(`[CollectorManager] Collector salvo: ${data.type}`);
  } catch (err) {
    console.error("[CollectorManager] Erro ao salvar:", err.message);
  }
}

function loadCollectors() {
  try {
    if (!fs.existsSync(COLLECTORS_FILE)) {
      return [];
    }

    const data = JSON.parse(fs.readFileSync(COLLECTORS_FILE, "utf8"));
    console.log(`[CollectorManager] ${data.length} collectors carregados`);
    return data;
  } catch (err) {
    console.error("[CollectorManager] Erro ao carregar:", err.message);
    return [];
  }
}

function removeCollector(messageId) {
  try {
    if (!fs.existsSync(COLLECTORS_FILE)) return;

    let collectors = JSON.parse(fs.readFileSync(COLLECTORS_FILE, "utf8"));
    collectors = collectors.filter(c => c.messageId !== messageId);

    fs.writeFileSync(COLLECTORS_FILE, JSON.stringify(collectors, null, 2));
    console.log(`[CollectorManager] Collector removido: ${messageId}`);
  } catch (err) {
    console.error("[CollectorManager] Erro ao remover:", err.message);
  }
}

function cleanupOldCollectors() {
  try {
    if (!fs.existsSync(COLLECTORS_FILE)) return;

    let collectors = JSON.parse(fs.readFileSync(COLLECTORS_FILE, "utf8"));
    const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);

    const before = collectors.length;
    collectors = collectors.filter(c => c.timestamp > sevenDaysAgo);
    const after = collectors.length;

    if (before > after) {
      fs.writeFileSync(COLLECTORS_FILE, JSON.stringify(collectors, null, 2));
      console.log(`[CollectorManager] Limpeza: ${before - after} collectors removidos`);
    }
  } catch (err) {
    console.error("[CollectorManager] Erro na limpeza:", err.message);
  }
}

// ============================================================================
// RESTAURAR COLLECTORS NO STARTUP
// ============================================================================

export async function restoreCollectors(client) {
  console.log("[CollectorManager] Iniciando restauração de collectors...");

  const collectors = loadCollectors();
  let restored = 0;
  let failed = 0;

  for (const collectorData of collectors) {
    try {
      await restoreCollectorByType(client, collectorData);
      restored++;
    } catch (err) {
      console.error(`[CollectorManager] Falha ao restaurar ${collectorData.type}:`, err.message);
      failed++;
      removeCollector(collectorData.messageId);
    }
  }

  console.log(`[CollectorManager] ✅ ${restored} restaurados | ❌ ${failed} falharam`);
  cleanupOldCollectors();
}

async function restoreCollectorByType(client, data) {
  const { type, channelId, messageId } = data;

  const channel = await client.channels.fetch(channelId).catch(() => null);
  if (!channel) {
    console.warn(`[CollectorManager] Canal ${channelId} não encontrado`);
    return;
  }

  const message = await channel.messages.fetch(messageId).catch(() => null);
  if (!message) {
    console.warn(`[CollectorManager] Mensagem ${messageId} não encontrada`);
    removeCollector(messageId);
    return;
  }

  switch (type) {
    case "controle_mediadores":
      await restoreControleMediadores(client, message, data);
      break;
    case "fila_1x1mob":
      await restoreFila1x1mob(client, message, data);
      break;
    case "thread_confirmacao":
      await restoreThreadConfirmacao(client, message, data);
      break;
    case "thread_sala":
      await restoreThreadSala(client, message, data);
      break;
    case "thread_vitoria":
      await restoreThreadVitoria(client, message, data);
      break;
    default:
      console.warn(`[CollectorManager] Tipo desconhecido: ${type}`);
  }
}

// ============================================================================
// RESTAURADORES ESPECÍFICOS
// ============================================================================

async function restoreControleMediadores(client, message, data) {
  console.log("[CollectorManager] Restaurando controle de mediadores...");

  const collector = message.createMessageComponentCollector({ time: 0 });

  collector.on("collect", async interaction => {
    const [namespace, acao] = interaction.customId.split(":");
    
    if (namespace === "controle") {
      const { default: controleCmd } = await import("../commands/mediator/controle.js");
      await controleCmd.handleButton(interaction, acao);
    }
  });

  console.log("✅ Controle de mediadores restaurado");
}

async function restoreFila1x1mob(client, message, data) {
  console.log(`[CollectorManager] Restaurando fila 1x1mob (R$${data.valor})...`);

  const { default: cmd1x1mob } = await import("../commands/queues/1x1mob.js");
  cmd1x1mob.startCollector(message, client, data.valor);

  console.log(`✅ Fila 1x1mob R$${data.valor} restaurada`);
}

async function restoreThreadConfirmacao(client, message, data) {
  console.log(`[CollectorManager] Restaurando thread confirmação: ${data.threadId}...`);

  const thread = await client.channels.fetch(data.threadId).catch(() => null);
  if (!thread) {
    console.warn(`Thread ${data.threadId} não encontrada`);
    removeCollector(message.id);
    return;
  }

  const { j1, j2, mediador, tipo, valor } = data;
  const confirmados = new Set(data.confirmados || []);

  const collector = message.createMessageComponentCollector({ time: 0, dispose: true });

  collector.on("collect", async i => {
    await i.deferUpdate().catch(() => {});

    if (i.customId === "cancelar") {
      await thread.delete().catch(() => {});
      removeCollector(message.id);
      return;
    }

    if (i.customId === "confirmar") {
      confirmados.add(i.user.id);

      const val = confirmados.size === 0 
        ? "Nenhum jogador confirmou ainda." 
        : [...confirmados].map(id => `<@${id}>`).join("\n");

      const { EmbedBuilder } = await import("discord.js");
      const upEmbed = new EmbedBuilder()
        .setTitle(`1x1 Mobile - ${tipo === "gelNormal" ? "Gel Normal" : "Gel Inf"} | R$ ${valor.toFixed(2).replace(".", ",")}`)
        .setColor(0xFFFFFF)
        .addFields({ name: "Confirmados:", value: val });

      await message.edit({ embeds: [upEmbed] }).catch(() => {});

      if (confirmados.has(j1) && confirmados.has(j2)) {
        collector.stop('confirmed');
        removeCollector(message.id);
        
        const { aguardarSala } = await import("../commands/queues/1x1mob.js");
        await aguardarSala(thread, j1, j2, mediador, valor, tipo === "gelNormal" ? "Gel Normal" : "Gel Inf");
      }
    }
  });

  console.log(`✅ Thread confirmação ${data.threadId} restaurada`);
}

async function restoreThreadSala(client, message, data) {
  console.log(`[CollectorManager] Restaurando thread sala: ${data.threadId}...`);

  const thread = await client.channels.fetch(data.threadId).catch(() => null);
  if (!thread) {
    console.warn(`Thread ${data.threadId} não encontrada`);
    removeCollector(message.id);
    return;
  }

  const { mediador } = data;
  const collector = message.createMessageComponentCollector({ time: 0 });

  collector.on("collect", async i => {
    await i.deferUpdate().catch(() => {});

    if (i.customId === "mostrarQr") {
      if (!mediador.qrcode || mediador.qrcode === "Não Definido") {
        return i.followUp({ content: "Nenhum QR Code cadastrado.", ephemeral: true }).catch(() => {});
      }

      const { EmbedBuilder } = await import("discord.js");
      const qrEmbed = new EmbedBuilder()
        .setTitle("QR Code:")
        .setColor(0xFFFFFF)
        .setImage(mediador.qrcode);

      await i.followUp({ embeds: [qrEmbed], ephemeral: true }).catch(() => {});
    }

    if (i.customId === "cancelarThread" && i.user.id === mediador.id) {
      await thread.delete().catch(() => {});
      removeCollector(message.id);
    }

    if (i.customId === "copiar_id") {
      await i.reply({ 
        content: data.idSala || "ID não disponível", 
        ephemeral: true 
      });
    }
  });

  console.log(`✅ Thread sala ${data.threadId} restaurada`);
}

async function restoreThreadVitoria(client, message, data) {
  console.log(`[CollectorManager] Restaurando thread vitória: ${data.threadId}...`);

  const thread = await client.channels.fetch(data.threadId).catch(() => null);
  if (!thread) {
    console.warn(`Thread ${data.threadId} não encontrada`);
    removeCollector(message.id);
    return;
  }

  const { mediador } = data;

  const { handleOperarioButtons } = await import("../systems/operario.js");

  const collector = message.createMessageComponentCollector({ time: 0 });

  collector.on("collect", async i => {
    await handleOperarioButtons(i);
  });

  console.log(`✅ Thread vitória ${data.threadId} restaurada`);
}

// ============================================================================
// HELPERS PARA COMANDOS
// ============================================================================

export function saveControleMediadores(channelId, messageId) {
  saveCollector({
    type: "controle_mediadores",
    channelId,
    messageId
  });
}

export function saveFila1x1mob(channelId, messageId, valor) {
  saveCollector({
    type: "fila_1x1mob",
    channelId,
    messageId,
    valor
  });
}

export function saveThreadConfirmacao(channelId, messageId, threadId, j1, j2, mediador, tipo, valor, confirmados = []) {
  saveCollector({
    type: "thread_confirmacao",
    channelId,
    messageId,
    threadId,
    j1,
    j2,
    mediador,
    tipo,
    valor,
    confirmados
  });
}

export function saveThreadSala(channelId, messageId, threadId, mediador, idSala = null) {
  saveCollector({
    type: "thread_sala",
    channelId,
    messageId,
    threadId,
    mediador,
    idSala
  });
}

export function saveThreadVitoria(channelId, messageId, threadId, mediador) {
  saveCollector({
    type: "thread_vitoria",
    channelId,
    messageId,
    threadId,
    mediador
  });
}

export function deleteCollector(messageId) {
  removeCollector(messageId);
}

// ============================================================================
// LIMPEZA AUTOMÁTICA
// ============================================================================

setInterval(() => {
  cleanupOldCollectors();
}, 60 * 60 * 1000);